#!/bin/bash

b='\033[0;34m'
h='\033[0;32m'
c='\033[0;36m'
m='\033[0;31m'
x='\033[0;35m'
k='\033[1;33m'
p='\033[1;37m'

mm(){
echo"ya"
}

banner(){
figlet FaceBrute | lolcat
echo -e $k"Author    "$h": "$c" NotGuardian"
echo -e $k"Github    "$h": "$c" https://github.com/NotHax"
echo -e $k"Instagram "$h": "$c" https://Instagram.com/notguardianyt"
echo
}

tool(){
banner
echo
echo -e $k"["$h"1"$k"]"$c" Mulai Menggunakan FaceBrute "
echo -e $k"["$h"2"$k"]"$c" Buat WordList"
echo -e $k"["$h"0"$k"]"$m" Exit"$c""
echo -e $k"Pilih 1/2/0?"
read -p ">>" pilih
if [ $pilih = "1" ]
then
clear
banner2
python2 brute.py
elif [ $pilih = "2" ]
then
echo -e $k"["$h"!"$k"]"$c" Buat WordList Mu"
echo -e $k"["$h"!"$k"]"$c" WordList Adalah Tempat Password Target"
echo -e $k"["$h"!"$k"]"$c" ( CTRL + X + Y + ENTER ) Untuk Men Save "
sleep 2
nano list.txt
echo -e $k"["$h"!"$k"]"$c" WordList Tersimpan Dengan Nama list.txt"
sleep 2
bash make.sh
elif [ $pilih = "0" ]
then
echo -e $k"["$h"!"$k"]"$r" Exit"$c""
else
kesalahan
fi
}

banner2(){
clear
figlet FaceBrute | lolcat
echo -e $k"Author    "$h": "$c" NotGuardian"
echo -e $k"Github    "$h": "$c" https://github.com/NotHax"
echo -e $k"Instagram "$h": "$c" https://Instagram.com/notguardianyt"
echo
echo -e $k"["$h"1"$k"]"$c" Mulai Cracking  "$k"["$h"2"$k"]"$c"Keluar"
echo
}

kesalahan(){
clear
echo -e $k"["$h"!"$k"]"$r" Pilihan Anda Tidak Ada"$c""
sleep 1
bash Make.sh
}

restart(){
clear
tool
}

clear
tool