#!/bin/bash

b='\033[0;34m'
h='\033[0;32m'
c='\033[0;36m'
m='\033[0;31m'
x='\033[0;35m'
k='\033[1;33m'
p='\033[1;37m'

mm(){
echo"ya"
}

load(){
figlet FaceBrute | lolcat
echo -e $k"["$h"!"$k"]"$c" Loading..."
      echo -e "\n"
      bar=" >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> "
      barlength=${#bar}
      i=0
      while((i<100)); do
          n=$((i*barlength / 100))
          printf "\e[00;32m\r[%-${barlength}s]\e[00m" "${bar:0:n}"
          ((i += RANDOM%5+2))
          sleep 0.2
        done
}

clear
load
clear
bash Make.sh
